/**
 * KinKonNao™ — API layer (Inventory Lambda Version)
 * ใช้ร่วมกับ KKN-InventoryHandler Lambda
 */

const Api = (() => {
  const KEY = 'fs_data_v1';

  // ========== Mock Storage (สำหรับโหมด offline/local) ==========
  const MockStorage = {
    load() {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : { pantries: {}, usageLogs: [], households: {} };
    },
    save(db) {
      localStorage.setItem(KEY, JSON.stringify(db));
    },
    id() {
      return (
        'IT' +
        Date.now().toString(36) +
        Math.random().toString(36).slice(2, 8).toUpperCase()
      );
    }
  };

  // ========== Helper: Auth & User ==========
  function getAuthToken() {
    const currentUser = Auth.current();
    if (!currentUser || !currentUser.token) {
      console.warn('No auth token found');
      return null;
    }
    return currentUser.token;
  }

  function getUserId() {
    const user = Auth.current();
    if (!user) return null;
    return user.userId || user.sub || user.id || null;
  }

  // ========== Helper: Mapping ระหว่าง frontend <-> AWS format ==========

  /**
   * แปลง format จาก frontend → body ที่ส่งเข้า Lambda
   */
  function toAWSFormat(item, userId) {
    return {
      OwnerId: userId,                          // optional (Lambda ใช้ x-user-id เป็นหลัก)
      ItemID: item.id || MockStorage.id(),
      Name: item.name,
      Category: item.category || '',
      Quantity: Number(item.quantity) || 0,
      Unit: item.unit || '',
      ExpiryDate: item.expiry,                  // YYYY-MM-DD
      Status: item.status || 'valid',
      UsedCount: item.usedCount || 0
    };
  }

  /**
   * แปลง format จาก AWS Lambda → format ที่ frontend ใช้
   */
  function fromAWSFormat(awsItem) {
    return {
      id: awsItem.ItemID,
      name: awsItem.Name,
      category: awsItem.Category,
      quantity: awsItem.Quantity,
      unit: awsItem.Unit,
      expiry: awsItem.ExpiryDate,
      status: awsItem.Status,
      createdAt: awsItem.AddedAt
        ? new Date(awsItem.AddedAt).getTime()
        : Date.now(),
      updatedAt: awsItem.UpdatedAt,
      usedCount: awsItem.UsedCount || 0,
    };
  }

  // =====================================================
  //                API Mode (AWS Lambda)
  // =====================================================

  /**
   * ดึงรายการวัตถุดิบทั้งหมด
   * GET /inventory?ownerId=xxx
   */
  async function apiListIngredients() {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const url = `${ApiConfig.apiBaseUrl}/inventory?ownerId=${encodeURIComponent(userId)}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'x-user-id': userId
      }
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json(); // array of AWS items
    const items = (data || []).map(fromAWSFormat);

    // sort ตามวันหมดอายุ
    return items.sort((a, b) => new Date(a.expiry) - new Date(b.expiry));
  }

  /**
   * เพิ่มวัตถุดิบใหม่
   * POST /inventory
   */
  async function apiCreateIngredient(item) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const awsItem = toAWSFormat(item, userId);

    const response = await fetch(`${ApiConfig.apiBaseUrl}/inventory`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-user-id': userId
      },
      body: JSON.stringify(awsItem)
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json(); // { message, itemId }

    // ประกอบ object ที่ frontend ใช้เอง (Lambda ตอนนี้ไม่คืนฟิลด์เต็ม)
    return {
      id: data.itemId,
      name: awsItem.Name,
      category: awsItem.Category,
      quantity: awsItem.Quantity,
      unit: awsItem.Unit,
      expiry: awsItem.ExpiryDate,
      status: awsItem.Status,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      usedCount: awsItem.UsedCount || 0,
    };
  }

  /**
   * แก้ไขวัตถุดิบ
   * PUT /inventory/{ItemID}
   */
  async function apiUpdateIngredient(itemId, updates) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    // mapping ชื่อ field ที่ส่งเข้า Lambda
    const awsUpdates = {};
    if (updates.name !== undefined) awsUpdates.Name = updates.name;
    if (updates.category !== undefined) awsUpdates.Category = updates.category;
    if (updates.quantity !== undefined) awsUpdates.Quantity = Number(updates.quantity);
    if (updates.unit !== undefined) awsUpdates.Unit = updates.unit;
    if (updates.expiry !== undefined) awsUpdates.ExpiryDate = updates.expiry;
    if (updates.status !== undefined) awsUpdates.Status = updates.status;

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/inventory/${encodeURIComponent(itemId)}`,
      {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'x-user-id': userId
        },
        body: JSON.stringify(awsUpdates)
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    // Lambda คืน { message: "Item updated" } ก็พอแล้ว
    await response.json().catch(() => ({}));

    // ให้ caller เอาไป merge เอง หรือ reload list อีกครั้ง
    return { id: itemId, ...updates };
  }

  /**
   * ลบวัตถุดิบ
   * DELETE /inventory/{ItemID}
   */
  async function apiDeleteIngredient(itemId) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/inventory/${encodeURIComponent(itemId)}`,
      {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-id': userId
        }
      }
    );

    if (!response.ok && response.status !== 204) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return { success: true };
  }

  // ===== สถิติสำหรับ Dashboard (โหมด API) =====

  /**
   * Weekly summary:
   * ในโหมด API ตอนนี้ยังใช้ inventory ล้วน ๆ ก่อน
   * ถ้าทำ Lambda analytics แล้ว ค่อยเปลี่ยน endpoint ตรงนี้ได้
   */
  function apiWeeklySummary() {
    return apiListIngredients().then(items => ({
      used: {},
      wasted: {},
      leftovers: items
    }));
  }

  function apiExpiringSoon(days = 3) {
    return apiListIngredients().then(items => {
      const cutoff = Date.now() + days * 86400000;
      const soon = items.filter(i => new Date(i.expiry).getTime() <= cutoff);
      return { my: soon, family: [] };
    });
  }

  // =====================================================
  //                Mock Mode (localStorage)
  // =====================================================

  function mockListIngredients(scope, ownerId, householdId) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    const arr = db.pantries[key] || [];
    return Promise.resolve(
      arr.sort((a, b) => new Date(a.expiry) - new Date(b.expiry))
    );
  }

  function mockCreateIngredient(scope, ownerId, householdId, item) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    db.pantries[key] = db.pantries[key] || [];

    const rec = {
      id: MockStorage.id(),
      createdAt: Date.now(),
      usedCount: 0,
      ...item
    };

    db.pantries[key].push(rec);
    MockStorage.save(db);
    return Promise.resolve(rec);
  }

  function mockUpdateIngredient(scope, ownerId, householdId, _id, patch) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    db.pantries[key] = (db.pantries[key] || []).map(it =>
      it.id === _id ? { ...it, ...patch } : it
    );
    MockStorage.save(db);
    return Promise.resolve(true);
  }

  function mockDeleteIngredient(scope, ownerId, householdId, _id, reason = 'used') {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    const item = (db.pantries[key] || []).find(x => x.id === _id);
    db.pantries[key] = (db.pantries[key] || []).filter(it => it.id !== _id);

    if (item) {
      db.usageLogs.push({
        id: MockStorage.id(),
        ownerKey: key,
        itemName: item.name,
        category: item.category,
        qty: item.quantity,
        unit: item.unit,
        expiry: item.expiry,
        when: Date.now(),
        reason
      });
    }

    MockStorage.save(db);
    return Promise.resolve(true);
  }

  // ===== สถิติ (mock mode) =====
  function mockWeeklySummary(ownerId, householdId) {
    const db = MockStorage.load();
    const since = Date.now() - 7 * 86400000;
    const logs = db.usageLogs.filter(
      l => l.when >= since && (l.ownerKey === ownerId || l.ownerKey === householdId)
    );

    const used = {},
      wasted = {};
    logs.forEach(l => {
      if (l.reason === 'waste') {
        wasted[l.itemName] = (wasted[l.itemName] || 0) + (Number(l.qty) || 1);
      } else {
        used[l.itemName] = (used[l.itemName] || 0) + (Number(l.qty) || 1);
      }
    });

    const my = db.pantries[ownerId] || [];
    const fam = db.pantries[householdId] || [];
    return Promise.resolve({ used, wasted, leftovers: [...my, ...fam] });
  }

  function mockExpiringSoon(ownerId, householdId, days = 3) {
    const db = MockStorage.load();
    const cut = Date.now() + days * 86400000;
    const filt = list =>
      (list || []).filter(i => new Date(i.expiry).getTime() <= cut);
    return Promise.resolve({
      my: filt(db.pantries[ownerId]),
      family: filt(db.pantries[householdId])
    });
  }

  // ===== Household mock functions (profile ใช้) =====
  function ensureHousehold(db, hhId) {
    db.households[hhId] = db.households[hhId] || {
      id: hhId,
      name: 'My Family',
      members: []
    };
    return db.households[hhId];
  }

  function createHousehold(hhId, name, user) {
    const db = MockStorage.load();
    const hh = ensureHousehold(db, hhId);
    hh.name = name || hh.name;
    if (!hh.members.find(m => m.id === user.id)) {
      hh.members.push({
        id: user.id,
        name: user.name,
        email: user.email,
        role: 'owner'
      });
    }
    MockStorage.save(db);
    return Promise.resolve(hh);
  }

  function joinHousehold(hhId, user) {
    const db = MockStorage.load();
    const hh = ensureHousehold(db, hhId);
    if (!hh.members.find(m => m.id === user.id)) {
      hh.members.push({
        id: user.id,
        name: user.name,
        email: user.email,
        role: 'member'
      });
    }
    MockStorage.save(db);
    return Promise.resolve(hh);
  }

  function getHousehold(hhId) {
    const db = MockStorage.load();
    return Promise.resolve(db.households[hhId] || null);
  }

  function inviteCode(hhId) {
    return btoa(hhId).replace(/=+$/, '').slice(0, 8).toUpperCase();
  }

  function decodeInvite(code) {
    try {
      const pad = code.length % 4 === 2 ? '==' : code.length % 4 === 3 ? '=' : '';
      return atob(code + pad);
    } catch {
      return null;
    }
  }

  // =====================================================
  //              Public API (เลือก mode ให้เอง)
  // =====================================================

  function listIngredients(scope, ownerId, householdId) {
    if (ApiConfig.mode === 'api') return apiListIngredients();
    return mockListIngredients(scope, ownerId, householdId);
  }

  function createIngredient(scope, ownerId, householdId, item) {
    if (ApiConfig.mode === 'api') return apiCreateIngredient(item);
    return mockCreateIngredient(scope, ownerId, householdId, item);
  }

  function updateIngredient(scope, ownerId, householdId, itemId, patch) {
    if (ApiConfig.mode === 'api') return apiUpdateIngredient(itemId, patch);
    return mockUpdateIngredient(scope, ownerId, householdId, itemId, patch);
  }

  function deleteIngredient(scope, ownerId, householdId, itemId, reason = 'used') {
    if (ApiConfig.mode === 'api') return apiDeleteIngredient(itemId);
    return mockDeleteIngredient(scope, ownerId, householdId, itemId, reason);
  }

  function weeklySummary(ownerId, householdId) {
    if (ApiConfig.mode === 'api') {
      return apiWeeklySummary();
    }
    return mockWeeklySummary(ownerId, householdId);
  }

  function expiringSoon(ownerId, householdId, days = 3) {
    if (ApiConfig.mode === 'api') {
      return apiExpiringSoon(days);
    }
    return mockExpiringSoon(ownerId, householdId, days);
  }

  return {
    listIngredients,
    createIngredient,
    updateIngredient,
    deleteIngredient,
    weeklySummary,
    expiringSoon,
    recommendFromPantry: () => Promise.resolve([]), // ไว้ทำทีหลัง
    createHousehold,
    joinHousehold,
    getHousehold,
    inviteCode,
    decodeInvite
  };
})();
