// apiConfig.js
// AWS Backend Configuration for KinKonNao

const ApiConfig = {
  mode: 'api',

  // เปลี่ยนเป็น API Gateway ตัวใหม่ของ KinKornNao
  apiBaseUrl: 'https://ovcauwjda5.execute-api.us-east-1.amazonaws.com',

  region: 'us-east-1',

  cognito: {
    userPoolId: 'us-east-1_7OWzCRhFJ',
    clientId: '4m0te8usu3cvp1nv5mhmr139vt',
    region: 'us-east-1'
  },

  householdId: 'GROUP#A001'
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ApiConfig;
}


/*const cognitoConfig = {
    region: "us-east-1",
    userPoolId: "us-east-1_7OWzCRhFJ",
    clientId: "4m0te8usu3cvp1nv5mhmr139vt"
};

const ApiConfig = {
    // ✅ Mode: 'api' = AWS Backend (DynamoDB + Lambda)
    mode: 'api',
    
    // ✅ API Gateway Invoke URL
    // HTTP API: KKNapi ($default stage)
    apiBaseUrl: 'https://eezwekiwrb.execute-api.us-east-1.amazonaws.com',
    
    // ✅ AWS Region
    region: 'us-east-1',
    
    // ✅ Amazon Cognito Configuration
    cognito: {
        // User Pool: us-east-1_Nsbd5UnWw
        userPoolId: 'us-east-1_Nsbd5UnWw',
        
        // App Client: KinKornNao-users
        clientId: '14iio68jjrvcolp8bub9h57m7b',
        
        region: 'us-east-1'
    },
    
    // ✅ Default Group ID (from DynamoDB GroupTable)
    householdId: 'GROUP#A001'
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ApiConfig;
}*/
