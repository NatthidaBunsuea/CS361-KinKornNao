/**
 * KinKonNao™ — Ingredient Form (เพิ่ม/แก้ไขวัตถุดิบ)
 * 
 * Updated version ที่รองรับ AWS Lambda inventoryHandler
 * 
 * Features:
 * - เพิ่มวัตถุดิบใหม่
 * - แก้ไขวัตถุดิบที่มีอยู่
 * - Validation และ error handling
 * - Toast notifications
 */

document.addEventListener('DOMContentLoaded', async () => {
  // ตรวจสอบ login
  const me = Auth.requireLogin();
  if (!me) return;

  // Mount header (ถ้ามีฟังก์ชัน UI.mountHeader)
  if (typeof UI !== 'undefined' && UI.mountHeader) {
    UI.mountHeader();
  }

  // อ่าน query parameters
  const params = new URLSearchParams(location.search);
  const scope = params.get('scope') || 'mine';
  const editId = params.get('id');

  const form = document.getElementById('form');
  
  // ====== โหลดข้อมูลสำหรับแก้ไข ======
  if (editId) {
    try {
      // โหลดรายการทั้งหมดแล้วหา item ที่ต้องการแก้ไข
      const items = await Api.listIngredients(scope, me.id, me.householdId);
      const item = items.find(x => x.id === editId);

      if (item) {
        // Fill form ด้วยข้อมูลเดิม
        form.name.value = item.name || '';
        form.quantity.value = item.quantity || '';
        form.unit.value = item.unit || 'pcs';
        form.category.value = item.category || '';
        
        // Format expiry date (YYYY-MM-DD)
        if (item.expiry) {
          const expiryDate = item.expiry.slice(0, 10);
          form.expiry.value = expiryDate;
        }

        // เปลี่ยน title
        const heading = document.querySelector('h2');
        if (heading) {
          heading.textContent = 'Edit your ingredient';
        }

        // เปลี่ยนปุ่ม SAVE เป็น UPDATE
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.textContent = 'UPDATE';
        }
      } else {
        showToast('Item not found', 'error');
        setTimeout(() => location.href = 'fridge-list.html', 1000);
      }
    } catch (error) {
      console.error('Error loading item:', error);
      showToast('Error loading item: ' + error.message, 'error');
    }
  }

  // ====== Handle Form Submit ======
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // รวบรวมข้อมูลจากฟอร์ม
    const formData = {
      name: form.name.value.trim().toLowerCase(),
      quantity: Number(form.quantity.value || 0),
      unit: form.unit.value.trim(),
      category: form.category.value.trim(),
      expiry: form.expiry.value
    };

    // Validation
    if (!formData.name) {
      showToast('Please enter ingredient name', 'error');
      return;
    }

    if (formData.quantity <= 0) {
      showToast('Quantity must be greater than 0', 'error');
      return;
    }

    if (!formData.expiry) {
      showToast('Please select expiration date', 'error');
      return;
    }

    // Disable form ขณะ submit
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Saving...';

    try {
      if (editId) {
        // แก้ไขรายการเดิม
        await Api.updateIngredient(scope, me.id, me.householdId, editId, formData);
        showToast('✅ Updated successfully!', 'success');
      } else {
        // เพิ่มรายการใหม่
        await Api.createIngredient(scope, me.id, me.householdId, formData);
        showToast('✅ Added successfully!', 'success');
      }

      // Redirect กลับไปหน้ารายการหลังจาก 500ms
      setTimeout(() => {
        location.href = 'fridge-list.html';
      }, 500);

    } catch (error) {
      console.error('Error saving ingredient:', error);
      showToast('❌ Error: ' + error.message, 'error');
      
      // Enable form กลับ
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });

  // ====== Set default expiry date (7 days from now) ======
  if (!editId) {
    const defaultExpiry = new Date();
    defaultExpiry.setDate(defaultExpiry.getDate() + 7);
    form.expiry.value = defaultExpiry.toISOString().split('T')[0];
  }
});

// ====== Toast Notification Function ======
function showToast(message, type = 'info') {
  // ลองใช้ UI.toast ถ้ามี
  if (typeof UI !== 'undefined' && UI.toast) {
    UI.toast(message);
    return;
  }

  // ถ้าไม่มี UI.toast ให้สร้างเอง
  let toastContainer = document.querySelector('.toast');
  
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast';
    document.body.appendChild(toastContainer);
  }

  // เพิ่ม CSS ถ้ายังไม่มี
  if (!document.querySelector('#toast-styles')) {
    const style = document.createElement('style');
    style.id = 'toast-styles';
    style.textContent = `
      .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 300px;
      }
      .toast-message {
        background: #333;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        margin-bottom: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease-out;
      }
      .toast-message.success {
        background: #10b981;
      }
      .toast-message.error {
        background: #ef4444;
      }
      .toast-message.info {
        background: #3b82f6;
      }
      @keyframes slideIn {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;
    document.head.appendChild(style);
  }

  // สร้าง toast message
  const toast = document.createElement('div');
  toast.className = `toast-message ${type}`;
  toast.textContent = message;
  toastContainer.appendChild(toast);

  // ลบ toast หลังจาก 3 วินาที
  setTimeout(() => {
    toast.style.animation = 'slideIn 0.3s ease-out reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}