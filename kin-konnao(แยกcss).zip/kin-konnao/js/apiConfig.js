// Toggle between 'mock' and 'api'
const ApiConfig = {
    mode: 'mock', // 'mock' | 'api'
    apiBaseUrl: 'https://your-api.execute-api.ap-southeast-1.amazonaws.com/prod',
    region: 'ap-southeast-1',
    householdId: 'H-1001'
  };