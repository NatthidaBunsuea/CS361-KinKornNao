
(function(){
    const KEY='fs_seed_v1'; if(localStorage.getItem(KEY)) return;
    const me = Auth.current() || { id:'seed-user', householdId: ApiConfig.householdId };
    const today = new Date();
    const plus = (d)=>{ const t=new Date(today); t.setDate(t.getDate()+d); return t.toISOString().slice(0,10); };
    Api.createIngredient('mine', me.id, me.householdId, { name:'egg', quantity:6, unit:'pcs', category:'protein', expiry: plus(5) });
    Api.createIngredient('mine', me.id, me.householdId, { name:'milk', quantity:1, unit:'L', category:'dairy', expiry: plus(3) });
    Api.createIngredient('family', me.id, me.householdId, { name:'rice', quantity:2, unit:'kg', category:'grain', expiry: plus(120) });
    Api.createIngredient('family', me.id, me.householdId, { name:'tomato', quantity:4, unit:'pcs', category:'vegetable', expiry: plus(4) });
    localStorage.setItem(KEY,'1');
  })();