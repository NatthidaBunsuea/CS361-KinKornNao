document.addEventListener('DOMContentLoaded', async ()=>{
    const me = Auth.requireLogin(); if(!me) return;
    UI.mountHeader();
  
    const scopeToggle = document.getElementById('scope');
    const listEl = document.getElementById('list');
    const emptyEl = document.getElementById('empty');
  
    async function render(){
      const scope = scopeToggle.value;
      const items = await Api.listIngredients(scope, me.id, me.householdId);
      listEl.innerHTML='';
      if(items.length===0){ emptyEl.style.display='block'; listEl.style.display='none'; return; }
      emptyEl.style.display='none'; listEl.style.display='grid';
      items.forEach(it=>{
        const days = UI.daysUntil(it.expiry);
        const badge = days<0 ? `<span class="badge" style="background:#fee2e2;color:#b91c1c">Expired</span>` :
                      days<=3 ? `<span class="badge" style="background:#fff7ed;color:#b45309">Soon</span>` :
                                `<span class="badge" style="background:#dcfce7;color:#065f46">Fresh</span>`;
        const row = document.createElement('div');
        row.style.display='grid';
        row.style.gridTemplateColumns='1.2fr .6fr .6fr .8fr .6fr .8fr';
        row.style.gap='10px';
        row.className='card';
        row.innerHTML = `
          <div><strong>${it.name}</strong><div class="small">${it.category||'-'}</div></div>
          <div>${it.quantity} ${it.unit||''}</div>
          <div>${UI.fmtDate(it.expiry)}</div>
          <div>${badge}</div>
          <div class="actions"><button class="btn" data-edit="${it.id}">Edit</button><button class="btn danger" data-del="${it.id}">Delete</button></div>
          <div class="small">ID: ${it.id}</div>`;
        listEl.appendChild(row);
      });
    }
  
    scopeToggle.addEventListener('change', render);
    document.getElementById('addBtn')?.addEventListener('click', ()=> location.href='./ingredient-form.html?scope='+scopeToggle.value);
  
    document.body.addEventListener('click', async (e)=>{
      const del = e.target.closest('[data-del]'); const edit = e.target.closest('[data-edit]'); const scope = scopeToggle.value;
      if(del){ const id = del.getAttribute('data-del'); const reason = confirm('Mark as waste? OK=WASTE, Cancel=USED') ? 'waste' : 'used'; await Api.deleteIngredient(scope, me.id, me.householdId, id, reason); UI.toast('Deleted'); render(); }
      if(edit){ const id = edit.getAttribute('data-edit'); location.href = './ingredient-form.html?id='+id+'&scope='+scope; }
    });
  
    render();
  });