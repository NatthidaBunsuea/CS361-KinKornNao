/**
 * KinKonNao™ — AI-Powered Menu Suggestions
 * บทบาท:
 *  - แสดงเมนูแนะนำจาก AI โดยวิเคราะห์วัตถุดิบในตู้เย็น
 *  - รองรับ cache (1 hour)
 *  - ปุ่ม Refresh สำหรับ generate ใหม่
 *  - แสดง matched ingredients และ additional ingredients
 *
 * พึ่งพา: api.js, auth.js, nav.js
 * DOM targets: #recipes, #refreshBtn, #loadingState, #recipeModal
 */

document.addEventListener('DOMContentLoaded', async () => {
  const me = Auth.requireLogin();
  if (!me) return;

  UI.mountHeader();

  const wrap = document.getElementById('recipes');
  const refreshBtn = document.getElementById('refreshBtn');
  const loadingState = document.getElementById('loadingState');
  const modal = document.getElementById('recipeModal');
  const mTitle = document.getElementById('mTitle');
  const mTime = document.getElementById('mTime');
  const mDifficulty = document.getElementById('mDifficulty');
  const mIng = document.getElementById('mIng');
  const mSteps = document.getElementById('mSteps');
  const mMatched = document.getElementById('mMatched');
  const mAdditional = document.getElementById('mAdditional');
  const mClose = document.getElementById('mClose');

  // ===== Load Suggestions =====
  async function loadSuggestions(forceRefresh = false) {
    try {
      // Show loading
      if (loadingState) {
        loadingState.style.display = 'block';
        loadingState.textContent = forceRefresh 
          ? '🤖 AI กำลังคิดเมนูใหม่...' 
          : '🍳 กำลังโหลดเมนูแนะนำ...';
      }
      wrap.innerHTML = '';
      if (refreshBtn) refreshBtn.disabled = true;

      // Fetch suggestions
      const recs = forceRefresh
        ? await Api.refreshSuggestions()
        : await Api.recommendFromPantry(me.id, me.householdId);

      // Hide loading
      if (loadingState) {
        loadingState.style.display = 'none';
      }
      if (refreshBtn) refreshBtn.disabled = false;

      // No suggestions
      if (!recs || recs.length === 0) {
        const emptyCard = document.createElement('div');
        emptyCard.className = 'card';
        emptyCard.style.gridColumn = '1 / -1';
        emptyCard.innerHTML = `
          <h3>😢 ยังไม่มีเมนูแนะนำ</h3>
          <p>กรุณาเพิ่มวัตถุดิบในตู้เย็นก่อน แล้วลองกดปุ่ม "รีเฟรชเมนู" อีกครั้ง</p>
          <a href="ingredient-form.html" class="btn" style="margin-top:12px">➕ เพิ่มวัตถุดิบ</a>
        `;
        wrap.appendChild(emptyCard);
        return;
      }

      // Render recipe cards
      recs.forEach(r => wrap.appendChild(recipeCard(r)));

      // Success toast
      if (forceRefresh) {
        showToast(`✨ สร้างเมนูใหม่สำเร็จ! พบ ${recs.length} เมนู`, 'success');
      }
    } catch (error) {
      console.error('Error loading suggestions:', error);

      // Hide loading
      if (loadingState) loadingState.style.display = 'none';
      if (refreshBtn) refreshBtn.disabled = false;

      // Show error
      const errorCard = document.createElement('div');
      errorCard.className = 'card';
      errorCard.style.gridColumn = '1 / -1';
      errorCard.style.background = '#fee';
      errorCard.innerHTML = `
        <h3>❌ เกิดข้อผิดพลาด</h3>
        <p>${error.message}</p>
        <button class="btn" onclick="location.reload()">รีโหลดหน้า</button>
      `;
      wrap.appendChild(errorCard);

      showToast('โหลดเมนูไม่สำเร็จ: ' + error.message, 'error');
    }
  }

  // ===== Recipe Card Component =====
  function recipeCard(r) {
    const card = document.createElement('div');
    card.className = 'card recipe';
    card.style.cursor = 'pointer';
    card.style.transition = 'transform 0.2s, box-shadow 0.2s';

    // Difficulty badge color
    const difficultyColors = {
      'ง่าย': '#10b981',
      'ปานกลาง': '#f59e0b',
      'ยาก': '#ef4444'
    };
    const difficultyColor = difficultyColors[r.difficulty] || '#6b7280';

    // Match percentage
    const matchedCount = (r.matchedIngredients || []).length;
    const totalCount = (r.ingredients || []).length;
    const matchPercent = totalCount > 0 
      ? Math.round((matchedCount / totalCount) * 100) 
      : 0;

    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:start;gap:8px;margin-bottom:8px">
        <h3 style="margin:0">${r.title}</h3>
        <div style="background:${difficultyColor};color:white;padding:4px 8px;border-radius:6px;font-size:12px;white-space:nowrap">
          ${r.difficulty || 'ปานกลาง'}
        </div>
      </div>
      
      <div class="small" style="margin-bottom:8px">
        ⏱️ เวลาโดยประมาณ: ${r.time} นาที
      </div>
      
      <div style="margin-bottom:8px">
        <div style="background:#f3f4f6;padding:8px;border-radius:6px;margin-bottom:4px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
            <span class="small">วัตถุดิบที่มีอยู่</span>
            <span class="small" style="font-weight:bold;color:${matchPercent >= 80 ? '#10b981' : matchPercent >= 50 ? '#f59e0b' : '#ef4444'}">
              ${matchPercent}%
            </span>
          </div>
          <div style="background:#e5e7eb;height:6px;border-radius:3px;overflow:hidden">
            <div style="background:${matchPercent >= 80 ? '#10b981' : matchPercent >= 50 ? '#f59e0b' : '#ef4444'};height:100%;width:${matchPercent}%;transition:width 0.3s"></div>
          </div>
        </div>
      </div>
      
      <div class="badge" style="background:#3b82f6;color:white;text-align:center">
        👆 คลิกเพื่อดูสูตร
      </div>
    `;

    // Hover effect
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-4px)';
      card.style.boxShadow = '0 8px 16px rgba(0,0,0,0.1)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0)';
      card.style.boxShadow = '';
    });

    card.addEventListener('click', () => openModal(r));
    return card;
  }

  // ===== Modal Functions =====
  function openModal(r) {
    mTitle.textContent = r.title;
    mTime.textContent = `⏱️ ~${r.time} นาที`;
    
    if (mDifficulty) {
      mDifficulty.textContent = `📊 ระดับ: ${r.difficulty || 'ปานกลาง'}`;
    }

    // Ingredients
    mIng.innerHTML = (r.ingredients || [])
      .map(i => `<li><strong>${i.name}</strong> — ${i.qty || ''}</li>`)
      .join('');

    // Steps
    mSteps.innerHTML = (r.steps || [])
      .map(s => `<li>${s}</li>`)
      .join('');

    // Matched ingredients
    if (mMatched && r.matchedIngredients && r.matchedIngredients.length > 0) {
      mMatched.innerHTML = `
        <h4 style="color:#10b981;margin-bottom:8px">✅ วัตถุดิบที่มีอยู่ในตู้เย็น</h4>
        <ul style="margin:0;padding-left:20px">
          ${r.matchedIngredients.map(ing => `<li>${ing}</li>`).join('')}
        </ul>
      `;
    } else if (mMatched) {
      mMatched.innerHTML = '';
    }

    // Additional ingredients
    if (mAdditional && r.additionalIngredients && r.additionalIngredients.length > 0) {
      mAdditional.innerHTML = `
        <h4 style="color:#f59e0b;margin-bottom:8px">🛒 วัตถุดิบที่ต้องซื้อเพิ่ม</h4>
        <ul style="margin:0;padding-left:20px">
          ${r.additionalIngredients.map(ing => `<li>${ing}</li>`).join('')}
        </ul>
      `;
    } else if (mAdditional) {
      mAdditional.innerHTML = '';
    }

    modal.style.display = 'block';
  }

  function closeModal() {
    modal.style.display = 'none';
  }

  // ===== Event Listeners =====
  if (mClose) {
    mClose.addEventListener('click', closeModal);
  }

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadSuggestions(true));
  }

  // ===== Toast Notification =====
  function showToast(message, type = 'info') {
    if (typeof UI !== 'undefined' && UI.toast) {
      UI.toast(message);
      return;
    }

    let toastContainer = document.querySelector('.toast');

    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast';
      document.body.appendChild(toastContainer);
    }

    if (!document.querySelector('#toast-styles')) {
      const style = document.createElement('style');
      style.id = 'toast-styles';
      style.textContent = `
        .toast {
          position: fixed;
          top: 20px;
          right: 20px;
          z-index: 9999;
          max-width: 300px;
        }
        .toast-message {
          background: #333;
          color: white;
          padding: 12px 20px;
          border-radius: 8px;
          margin-bottom: 10px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          animation: slideIn 0.3s ease-out;
        }
        .toast-message.success {
          background: #10b981;
        }
        .toast-message.error {
          background: #ef4444;
        }
        .toast-message.info {
          background: #3b82f6;
        }
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `;
      document.head.appendChild(style);
    }

    const toast = document.createElement('div');
    toast.className = `toast-message ${type}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'slideIn 0.3s ease-out reverse';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ===== Initial Load =====
  loadSuggestions(false);
});