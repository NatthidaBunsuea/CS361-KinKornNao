document.addEventListener('DOMContentLoaded', () => {

  // ===== STATIC JSON (ข้อมูลจำลอง / ฝังในไฟล์) =====
  const data = {
    used: {
      Egg: 8,
      Rice: 5,
      Tomato: 4,
      Milk: 3,
      Chicken: 6,
      Pasta: 4
    },
    wasted: {
      Tomato: 1,
      Milk: 1,
      Lettuce: 2
    },
    leftovers: [
      {name:'pasta', quantity:1, unit:'pack', category:'grain', expiry:'2025-11-20'},
      {name:'pork', quantity:10, unit:'pcs', category:'protein', expiry:'2025-11-23'},
      {name:'milk', quantity:1, unit:'L', category:'dairy', expiry:'2025-11-24'},
    ]
  };
  // ==============================================

  // ใช้ STATIC JSON ตรงนี้ ไม่ต้อง API
  const usedLabels = Object.keys(data.used);
  const usedVals   = usedLabels.map(k => data.used[k]);
  const wasteLabels= Object.keys(data.wasted);
  const wasteVals  = wasteLabels.map(k => data.wasted[k]);

  // 1) Most Used (Bar Chart)
  new Chart(document.getElementById('usedChart').getContext('2d'), {
    type: 'bar',
    data: {
      labels: usedLabels,
      datasets: [{
        label: 'Used (qty)',
        data: usedVals,
        borderRadius: 12,
        backgroundColor: 'rgba(75, 192, 192, 0.5)'
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false }},
      scales: { y: { beginAtZero: true }}
    }
  });

  // 2) Wasted (Doughnut Chart)
  new Chart(document.getElementById('wasteChart').getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: wasteLabels,
      datasets: [{
        data: wasteVals,
        backgroundColor: ['#ff6384', '#36a2eb', '#ffce56']
      }]
    },
    options: {
      responsive: true,
      cutout: '55%',
      plugins: { legend: { position: 'bottom' }}
    }
  });

  // 3) Used vs Waste (Stacked Horizontal Bar)
  const allKeys = Array.from(new Set([...usedLabels, ...wasteLabels]));
  const usedAll = allKeys.map(k => data.used[k] || 0);
  const wasteAll= allKeys.map(k => data.wasted[k] || 0);

  new Chart(document.getElementById('stackedChart').getContext('2d'), {
    type: 'bar',
    data: {
      labels: allKeys,
      datasets: [
        { label: 'Used',  data: usedAll },
        { label: 'Waste', data: wasteAll }
      ]
    },
    options: {
      indexAxis:'y',
      responsive:true,
      plugins:{ legend:{ position:'bottom' }},
      scales:{
        x:{ beginAtZero:true },
        y:{ stacked:true }
      }
    }
  });

  // 4) Trend (Line Chart)
  const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const spread = t => {
    const a = Array(7).fill(0);
    for(let i = 0; i<t; i++){
      a[Math.floor(Math.random()*7)]++;
    }
    return a;
  };

  new Chart(document.getElementById('trendChart').getContext('2d'), {
    type:'line',
    data:{
      labels: days,
      datasets:[
        { label:'Used', data:spread(usedVals.reduce((a,b)=>a+b,0)), tension:.3 },
        { label:'Waste', data:spread(wasteVals.reduce((a,b)=>a+b,0)), tension:.3 }
      ]
    },
    options:{
      responsive:true,
      plugins:{ legend:{ position:'bottom' }},
      scales:{ y:{ beginAtZero:true }}
    }
  });

});
