/**
 * KinKonNao™ — Authentication (Mock + AWS Cognito SRP)
 */

const Auth = (() => {
  const KEY = 'fs_auth';
  const now = () => Date.now();

  // ====== Mock Authentication ======
  function genToken() {
    return btoa(String(Math.random()).slice(2) + '.' + now());
  }

  function mockLogin(email, password) {
    if (!email || !password) throw new Error('Email and password required');

    const user = {
      id: 'U-' + Math.random().toString(36).slice(2, 8),
      name: email.split('@')[0],
      email,
      householdId: ApiConfig.householdId || 'H-1001',
      token: genToken(),
      expiresAt: now() + 1000 * 60 * 60 * 8, // 8 hours
      authMode: 'mock'
    };

    localStorage.setItem(KEY, JSON.stringify(user));
    return user;
  }
// ====== Cognito Authentication (SRP Login) ======

async function cognitoLogin(email, password) {
  // อ่านข้อมูลเก่าเผื่อใช้
  let previousAvatar = null;
  
  try {
    const rawPrev = localStorage.getItem(KEY);
    if (rawPrev) {
      const prev = JSON.parse(rawPrev);
      previousAvatar = prev.avatar;
    }
  } catch (e) {
    console.warn('Failed to parse previous auth state', e);
  }

  return new Promise((resolve, reject) => {
    const authDetails = new AmazonCognitoIdentity.AuthenticationDetails({
      Username: email,
      Password: password,
    });

    const userPool = new AmazonCognitoIdentity.CognitoUserPool({
      UserPoolId: ApiConfig.cognito.userPoolId,
      ClientId: ApiConfig.cognito.clientId
    });

    const userData = {
      Username: email,
      Pool: userPool,
    };

    const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    cognitoUser.authenticateUser(authDetails, {
  onSuccess: async (result) => {
    const idToken = result.getIdToken().getJwtToken();
    const accessToken = result.getAccessToken().getJwtToken();
    const parsed = parseJWT(idToken);

    const user = {
      id: parsed.sub,
      userId: parsed.sub,
      sub: parsed.sub,
      name: parsed.email.split("@")[0],
      email: parsed.email,
      token: idToken,
      accessToken,
      authMode: 'cognito',
      householdId: null,
      avatar: previousAvatar || null
    };

    localStorage.setItem(KEY, JSON.stringify(user));

    // ========== โหลดโปรไฟล์จาก DynamoDB ==========
    let profile = null;
    try {
      profile = await Api.getUserProfile();
      if (profile && profile.primaryGroupID) {
        user.householdId = profile.primaryGroupID;
      }
    } catch (err) {
      console.warn("⚠ No profile in DB yet:", err);
    }

    // Save again after sync
    localStorage.setItem(KEY, JSON.stringify(user));

    resolve(user);
  },

      onFailure: (err) => {
        reject(err);
      }
    });
  });
}
// เพิ่มฟังก์ชันสำหรับอัพเดต user data
function updateUser(patch) {
  const raw = localStorage.getItem(KEY);
  if (!raw) return;

  const user = JSON.parse(raw);
  Object.assign(user, patch);
  localStorage.setItem(KEY, JSON.stringify(user));
}


  // ====== JWT Parser ======
  function parseJWT(token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64).split('').map(c => {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join('')
      );
      return JSON.parse(jsonPayload);
    } catch (e) {
      console.error('Error parsing JWT:', e);
      return null;
    }
  }

  // ====== Token Expiry Check ======
  function isTokenExpired(token) {
    const payload = parseJWT(token);
    if (!payload || !payload.exp) return true;
    return Date.now() >= payload.exp * 1000;
  }

  // ====== API ======
  async function login(email, password) {
    if (ApiConfig.mode === 'api' && ApiConfig.cognito) {
      return await cognitoLogin(email, password);
    } else {
      return mockLogin(email, password);
    }
  }

  function logout() {
    localStorage.removeItem(KEY);
    location.href = '../Login.html';
  }

  function current() {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;

    try {
      const user = JSON.parse(raw);

      if (user.authMode === 'mock') {
        if (user.expiresAt < now()) {
          localStorage.removeItem(KEY);
          return null;
        }
        return user;
      }

      if (user.token && isTokenExpired(user.token)) {
        localStorage.removeItem(KEY);
        return null;
      }

      return user;
    } catch (e) {
      console.error('Error parsing auth:', e);
      return null;
    }
  }

  function requireLogin() {
    const user = current();
    if (!user) {
      location.href = '../Login.html';
      return null;
    }
    return user;
  }

  function getUserId() {
    const user = current();
    return user ? (user.userId || user.sub || user.id) : null;
  }

  function getToken() {
    const user = current();
    return user ? user.token : null;
  }

  return {
    login,
    logout,
    current,
    requireLogin,
    getUserId,
    getToken,
    parseJWT,
    isTokenExpired,
    updateUser
  };
})();
