/**
 * KinKonNao™ — API layer (Inventory Lambda Version + Menu Suggestions)
 * ใช้ร่วมกับ KKN-InventoryHandler Lambda และ KKN-MenuSuggestion Lambda
 */

const Api = (() => {
  const KEY = 'fs_data_v1';

  // ========== Mock Storage (สำหรับโหมด offline/local) ==========
  const MockStorage = {
    load() {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : { pantries: {}, usageLogs: [], households: {} };
    },
    save(db) {
      localStorage.setItem(KEY, JSON.stringify(db));
    },
    id() {
      return (
        'IT' +
        Date.now().toString(36) +
        Math.random().toString(36).slice(2, 8).toUpperCase()
      );
    }
  };

  // ========== Helper: Auth & User ==========
  function getAuthToken() {
    const currentUser = Auth.current();
    if (!currentUser || !currentUser.token) {
      console.warn('No auth token found');
      return null;
    }
    return currentUser.token;
  }

  function getUserId() {
    const user = Auth.current();
    if (!user) return null;
    return user.userId || user.sub || user.id || null;
  }

  // ========== Helper: Mapping ระหว่าง frontend <-> AWS format ==========

  /**
   * แปลง format จาก frontend → body ที่ส่งเข้า Lambda
   */
  function toAWSFormat(item, userId) {
    return {
      OwnerId: userId,
      ItemID: item.id || MockStorage.id(),
      Name: item.name,
      Category: item.category || '',
      Quantity: Number(item.quantity) || 0,
      Unit: item.unit || '',
      ExpiryDate: item.expiry,
      Status: item.status || 'valid',
      UsedCount: item.usedCount || 0
    };
  }

  /**
   * แปลง format จาก AWS Lambda → format ที่ frontend ใช้
   */
  function fromAWSFormat(awsItem) {
    return {
      id: awsItem.ItemID,
      name: awsItem.Name,
      category: awsItem.Category,
      quantity: awsItem.Quantity,
      unit: awsItem.Unit,
      expiry: awsItem.ExpiryDate,
      status: awsItem.Status,
      createdAt: awsItem.AddedAt
        ? new Date(awsItem.AddedAt).getTime()
        : Date.now(),
      updatedAt: awsItem.UpdatedAt,
      usedCount: awsItem.UsedCount || 0,
      ownerName: awsItem.OwnerName || null, 
    };
  }

  // =====================================================
  //                API Mode (AWS Lambda)
  // =====================================================

  /**
   * ดึงรายการวัตถุดิบทั้งหมด
   * GET /inventory?ownerId=xxx
   */
  async function apiListIngredients() {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const url = `${ApiConfig.apiBaseUrl}/inventory?ownerId=${encodeURIComponent(userId)}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'x-user-id': userId
      }
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    const items = (data || []).map(fromAWSFormat);

    return items.sort((a, b) => new Date(a.expiry) - new Date(b.expiry));
  }

  /**
   * เพิ่มวัตถุดิบใหม่
   * POST /inventory
   */
  async function apiCreateIngredient(item) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const awsItem = toAWSFormat(item, userId);

    const response = await fetch(`${ApiConfig.apiBaseUrl}/inventory`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-user-id': userId
      },
      body: JSON.stringify(awsItem)
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json();

    return {
      id: data.itemId,
      name: awsItem.Name,
      category: awsItem.Category,
      quantity: awsItem.Quantity,
      unit: awsItem.Unit,
      expiry: awsItem.ExpiryDate,
      status: awsItem.Status,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      usedCount: awsItem.UsedCount || 0,
    };
  }

  /**
   * แก้ไขวัตถุดิบ
   * PUT /inventory/{ItemID}
   */
  async function apiUpdateIngredient(itemId, updates) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const awsUpdates = {};
    if (updates.name !== undefined) awsUpdates.Name = updates.name;
    if (updates.category !== undefined) awsUpdates.Category = updates.category;
    if (updates.quantity !== undefined) awsUpdates.Quantity = Number(updates.quantity);
    if (updates.unit !== undefined) awsUpdates.Unit = updates.unit;
    if (updates.expiry !== undefined) awsUpdates.ExpiryDate = updates.expiry;
    if (updates.status !== undefined) awsUpdates.Status = updates.status;

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/inventory/${encodeURIComponent(itemId)}`,
      {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'x-user-id': userId
        },
        body: JSON.stringify(awsUpdates)
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    await response.json().catch(() => ({}));

    return { id: itemId, ...updates };
  }

  /**
   * ลบวัตถุดิบ
   * DELETE /inventory/{ItemID}
   */
  async function apiDeleteIngredient(itemId) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/inventory/${encodeURIComponent(itemId)}`,
      {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-id': userId
        }
      }
    );

    if (!response.ok && response.status !== 204) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return { success: true };
  }

  // ===== สถิติสำหรับ Dashboard (โหมด API) =====

  function apiWeeklySummary() {
    return apiListIngredients().then(items => ({
      used: {},
      wasted: {},
      leftovers: items
    }));
  }

  function apiExpiringSoon(days = 3) {
    return apiListIngredients().then(items => {
      const cutoff = Date.now() + days * 86400000;
      const soon = items.filter(i => new Date(i.expiry).getTime() <= cutoff);
      return { my: soon, family: [] };
    });
  }

  // ===== AI Menu Suggestions =====

  /**
   * ดึงคำแนะนำเมนูอาหารจาก AI
   * GET /suggestions?ownerId=xxx
   */
  async function apiRecommendFromPantry() {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    // Use separate API endpoint for menu suggestions
    const suggestionsApi = 'https://ovcauwjda5.execute-api.us-east-1.amazonaws.com';
    const url = `${suggestionsApi}/suggestions?ownerId=${encodeURIComponent(userId)}`;

    console.log('Fetching menu suggestions from:', url);

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'x-user-id': userId
      }
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log('Menu suggestions response:', data);

    return data.suggestions || [];
  }

  /**
   * Refresh menu suggestions (force new AI generation)
   * POST /suggestions/refresh
   */
  async function apiRefreshSuggestions() {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    // Use separate API endpoint for menu suggestions
    const suggestionsApi = 'https://ovcauwjda5.execute-api.us-east-1.amazonaws.com';
    const url = `${suggestionsApi}/suggestions/refresh`;

    console.log('Refreshing menu suggestions...');

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-user-id': userId
      }
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log('Refreshed menu suggestions:', data);

    return data.suggestions || [];
  }

  // =====================================================
  //                Mock Mode (localStorage)
  // =====================================================

  function mockListIngredients(scope, ownerId, householdId) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    const arr = db.pantries[key] || [];
    return Promise.resolve(
      arr.sort((a, b) => new Date(a.expiry) - new Date(b.expiry))
    );
  }

  function mockCreateIngredient(scope, ownerId, householdId, item) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    db.pantries[key] = db.pantries[key] || [];

    const rec = {
      id: MockStorage.id(),
      createdAt: Date.now(),
      usedCount: 0,
      ...item
    };

    db.pantries[key].push(rec);
    MockStorage.save(db);
    return Promise.resolve(rec);
  }

  function mockUpdateIngredient(scope, ownerId, householdId, _id, patch) {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    db.pantries[key] = (db.pantries[key] || []).map(it =>
      it.id === _id ? { ...it, ...patch } : it
    );
    MockStorage.save(db);
    return Promise.resolve(true);
  }

  function mockDeleteIngredient(scope, ownerId, householdId, _id, reason = 'used') {
    const db = MockStorage.load();
    const key = scope === 'family' ? householdId : ownerId;
    const item = (db.pantries[key] || []).find(x => x.id === _id);
    db.pantries[key] = (db.pantries[key] || []).filter(it => it.id !== _id);

    if (item) {
      db.usageLogs.push({
        id: MockStorage.id(),
        ownerKey: key,
        itemName: item.name,
        category: item.category,
        qty: item.quantity,
        unit: item.unit,
        expiry: item.expiry,
        when: Date.now(),
        reason
      });
    }

    MockStorage.save(db);
    return Promise.resolve(true);
  }

  function mockWeeklySummary(ownerId, householdId) {
    const db = MockStorage.load();
    const since = Date.now() - 7 * 86400000;
    const logs = db.usageLogs.filter(
      l => l.when >= since && (l.ownerKey === ownerId || l.ownerKey === householdId)
    );

    const used = {},
      wasted = {};
    logs.forEach(l => {
      if (l.reason === 'waste') {
        wasted[l.itemName] = (wasted[l.itemName] || 0) + (Number(l.qty) || 1);
      } else {
        used[l.itemName] = (used[l.itemName] || 0) + (Number(l.qty) || 1);
      }
    });

    const my = db.pantries[ownerId] || [];
    const fam = db.pantries[householdId] || [];
    return Promise.resolve({ used, wasted, leftovers: [...my, ...fam] });
  }

  function mockExpiringSoon(ownerId, householdId, days = 3) {
    const db = MockStorage.load();
    const cut = Date.now() + days * 86400000;
    const filt = list =>
      (list || []).filter(i => new Date(i.expiry).getTime() <= cut);
    return Promise.resolve({
      my: filt(db.pantries[ownerId]),
      family: filt(db.pantries[householdId])
    });
  }

  function mockRecommendFromPantry() {
    // Mock suggestions
    return Promise.resolve([
      {
        title: 'ไข่เจียว',
        time: 10,
        difficulty: 'ง่าย',
        ingredients: [
          { name: 'ไข่', qty: '2 ฟอง' },
          { name: 'น้ำมัน', qty: '2 ช้อนโต๊ะ' }
        ],
        steps: [
          'ตีไข่ให้เข้ากัน',
          'ตั้งกระทะใส่น้ำมัน ให้ร้อนจัด',
          'เทไข่ลงไป รอจนสุก',
          'พลิกอีกด้าน สักครู่จึงตักขึ้น'
        ],
        matchedIngredients: ['ไข่'],
        additionalIngredients: ['น้ำมัน']
      }
    ]);
  }

  // ===== Household mock functions (profile ใช้) =====
  function ensureHousehold(db, hhId) {
    db.households[hhId] = db.households[hhId] || {
      id: hhId,
      name: 'My Family',
      members: []
    };
    return db.households[hhId];
  }

  /**
 * ดึงข้อมูล user profile จาก DynamoDB (รวม primaryGroupID)
 */
  // ===== User Profile (DynamoDB KKN-Users ผ่าน Users Lambda) =====
  async function apiGetUserProfile() {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    // ใช้ /users/me แทนการส่ง userId เอง เพื่อให้ Lambda อ่านจาก JWT
    const url = `${ApiConfig.apiBaseUrl}/users/me`;

    const res = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      }
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson.error || errJson.message || `HTTP ${res.status}`);
    }

    // expected: { userId, email, displayName, primaryGroupID, avatar, status }
    const data = await res.json();
    console.log('👤 Loaded user profile from API:', data);
    return data;
  }



  function createHousehold(hhId, name, user) {
    const db = MockStorage.load();
    const hh = ensureHousehold(db, hhId);
    hh.name = name || hh.name;
    if (!hh.members.find(m => m.id === user.id)) {
      hh.members.push({
        id: user.id,
        name: user.name,
        email: user.email,
        role: 'owner'
      });
    }
    MockStorage.save(db);
    return Promise.resolve(hh);
  }

  function joinHousehold(hhId, user) {
    const db = MockStorage.load();
    const hh = ensureHousehold(db, hhId);
    if (!hh.members.find(m => m.id === user.id)) {
      hh.members.push({
        id: user.id,
        name: user.name,
        email: user.email,
        role: 'member'
      });
    }
    MockStorage.save(db);
    return Promise.resolve(hh);
  }

  function getHousehold(hhId) {
    const db = MockStorage.load();
    return Promise.resolve(db.households[hhId] || null);
  }

  function inviteCode(hhId) {
    return btoa(hhId).replace(/=+$/, '').slice(0, 8).toUpperCase();
  }

  function decodeInvite(code) {
    try {
      const pad = code.length % 4 === 2 ? '==' : code.length % 4 === 3 ? '=' : '';
      return atob(code + pad);
    } catch {
      return null;
    }
  }

  // =====================================================
  //              Public API (เลือก mode ให้เอง)
  // =====================================================

  function listIngredients(scope, ownerId, householdId) {
    if (ApiConfig.mode === 'api') return apiListIngredients();
    return mockListIngredients(scope, ownerId, householdId);
  }

  function createIngredient(scope, ownerId, householdId, item) {
    if (ApiConfig.mode === 'api') return apiCreateIngredient(item);
    return mockCreateIngredient(scope, ownerId, householdId, item);
  }

  function updateIngredient(scope, ownerId, householdId, itemId, patch) {
    if (ApiConfig.mode === 'api') return apiUpdateIngredient(itemId, patch);
    return mockUpdateIngredient(scope, ownerId, householdId, itemId, patch);
  }

  function deleteIngredient(scope, ownerId, householdId, itemId, reason = 'used') {
    if (ApiConfig.mode === 'api') return apiDeleteIngredient(itemId);
    return mockDeleteIngredient(scope, ownerId, householdId, itemId, reason);
  }

  function weeklySummary(ownerId, householdId) {
    if (ApiConfig.mode === 'api') {
      return apiWeeklySummary();
    }
    return mockWeeklySummary(ownerId, householdId);
  }

  function expiringSoon(ownerId, householdId, days = 3) {
    if (ApiConfig.mode === 'api') {
      return apiExpiringSoon(days);
    }
    return mockExpiringSoon(ownerId, householdId, days);
  }

  function recommendFromPantry(ownerId, householdId) {
    if (ApiConfig.mode === 'api') {
      return apiRecommendFromPantry();
    }
    return mockRecommendFromPantry();
  }

  function refreshSuggestions() {
    if (ApiConfig.mode === 'api') {
      return apiRefreshSuggestions();
    }
    return mockRecommendFromPantry();
  }

  
  // =====================================================
  //          Group Sharing API Functions
  // =====================================================

  // ช่วย encode groupId ให้เป็น URL-safe (กันปัญหา # ใน path)
  function encodeGroupId(groupId) {
    return encodeURIComponent(groupId);
  }

  /**
   * สร้างกลุ่มใหม่
   */
  async function apiCreateGroup(groupName, userName, userEmail) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const response = await fetch(`${ApiConfig.apiBaseUrl}/groups`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-user-id': userId
      },
      body: JSON.stringify({
        groupName,
        userName: userName || 'Owner',
        userEmail: userEmail || ''
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return await response.json();
  }

  /**
   * สร้างโค้ดเชิญสมาชิก
   */
  async function apiGenerateInviteCode(groupId) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const safeGroupId = encodeGroupId(groupId);

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/groups/${safeGroupId}/invite`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'x-user-id': userId
        }
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return await response.json();
  }

  /**
   * เข้าร่วมกลุ่มด้วยโค้ดเชิญ
   */
  async function apiJoinGroup(inviteCode, userName, userEmail) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const response = await fetch(`${ApiConfig.apiBaseUrl}/groups/join`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-user-id': userId
      },
      body: JSON.stringify({
        inviteCode: inviteCode.toUpperCase(),
        userName: userName || 'Member',
        userEmail: userEmail || ''
      })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return await response.json();
  }

  /**
   * ดึงรายชื่อสมาชิกในกลุ่ม
   */
  async function apiListGroupMembers(groupId) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const safeGroupId = encodeGroupId(groupId);

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/groups/${safeGroupId}/members`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-user-id': userId
        }
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    return data.members || [];
  }

  /**
   * ลบสมาชิกออกจากกลุ่ม
   */
  async function apiRemoveGroupMember(groupId, userId) {
  const token = getAuthToken();

  const res = await fetch(`${ApiConfig.apiBaseUrl}/groups/${groupId}/members/${userId}`, {
    method: "DELETE",
    headers: {
      "Authorization": `Bearer ${token}`,
      "x-user-id": userId
    }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to leave household");
  }

  return await res.json();
}

  /**
   * ดึงรายการวัตถุดิบของกลุ่ม
   */
  async function apiListGroupInventory(groupId) {
  const token = getAuthToken();
  const userId = getUserId();

  const res = await fetch(`${ApiConfig.apiBaseUrl}/groups/${groupId}/inventory`, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${token}`,
      "x-user-id": userId
    }
  });

  if (!res.ok) throw new Error("Cannot load group items");
  return (await res.json()).items;
}

  /**
   * เพิ่มวัตถุดิบลงในกลุ่ม
   */
  async function apiAddGroupItem(groupId, item) {
    const token = getAuthToken();
    if (!token) throw new Error('Not authenticated');

    const userId = getUserId();
    if (!userId) throw new Error('Missing user id');

    const safeGroupId = encodeGroupId(groupId);

    const response = await fetch(
      `${ApiConfig.apiBaseUrl}/groups/${safeGroupId}/inventory`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'x-user-id': userId
        },
        body: JSON.stringify(item)
      }
    );

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || error.message || `HTTP ${response.status}`);
    }

    return await response.json();
  }

  // Public API functions (ลบ mock group-sharing ทิ้ง ใช้ API จริงอย่างเดียว)
  function createGroup(groupName, userName, userEmail) {
    return apiCreateGroup(groupName, userName, userEmail);
  }

  function generateInviteCode(groupId) {
    return apiGenerateInviteCode(groupId);
  }

  function joinGroup(inviteCode, userName, userEmail) {
    return apiJoinGroup(inviteCode, userName, userEmail);
  }

  function listGroupMembers(groupId) {
    return apiListGroupMembers(groupId);
  }

   function removeGroupMember(groupId, memberId) {
    return apiRemoveGroupMember(groupId, memberId);
  }

  function listGroupInventory(groupId) {
    return apiListGroupInventory(groupId);
  }

  function addGroupItem(groupId, item) {
    return apiAddGroupItem(groupId, item);
  }


  return {
    listIngredients,
    createIngredient,
    updateIngredient,
    deleteIngredient,
    weeklySummary,
    expiringSoon,
    recommendFromPantry,
    refreshSuggestions,
    getUserProfile: apiGetUserProfile,
    createHousehold,
    joinHousehold,
    getHousehold,
    inviteCode,
    decodeInvite,
    // Group Sharing functions
    createGroup,
    generateInviteCode,
    joinGroup,
    listGroupMembers,
    removeGroupMember,
    listGroupInventory,
    addGroupItem
  };
})();