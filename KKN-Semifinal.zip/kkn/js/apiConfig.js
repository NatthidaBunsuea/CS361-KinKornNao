// apiConfig.js
// AWS Backend Configuration for KinKonNao

const ApiConfig = {
  mode: "api",
  apiBaseUrl: "https://xdt0nrnf7k.execute-api.us-east-1.amazonaws.com",
  region: "us-east-1",

  cognito: {
    userPoolId: 'us-east-1_7OWzCRhFJ',
    clientId: '4m0te8usu3cvp1nv5mhmr139vt',
    region: 'us-east-1'
  },

  householdId: 'GROUP#A001'
};

/*
const ApiConfig = {
  mode: 'api',

  // เปลี่ยนเป็น API Gateway ตัวใหม่ของ KinKornNao
  apiBaseUrl: 'https://ovcauwjda5.execute-api.us-east-1.amazonaws.com',

  region: 'us-east-1',

  cognito: {
    userPoolId: 'us-east-1_7OWzCRhFJ',
    clientId: '4m0te8usu3cvp1nv5mhmr139vt',
    region: 'us-east-1'
  },

  householdId: 'GROUP#A001'
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ApiConfig;
}
*/
