/**
 * KinKonNao™ — Profile & Household Management (Updated for Group Sharing)
 */

document.addEventListener('DOMContentLoaded', async () => {
  if (typeof UI !== 'undefined' && UI.mountHeader) {
    UI.mountHeader();
  }

  // 1) ต้อง login ก่อน
  const me = Auth.requireLogin();
  if (!me) return;

  // 2) เติมค่าจาก local ก่อน
  document.getElementById('name').textContent = me.name || 'User';
  document.getElementById('email').textContent = me.email || '';
  document.getElementById('displayName').value = me.name || '';

  const householdLabel = document.getElementById('household');
  const householdIdBadge = document.getElementById('householdId');
  const memberList = document.getElementById('memberList');

  function setHouseholdUI(hid) {
    const text = hid || '-';
    if (householdLabel) householdLabel.textContent = text;
    if (householdIdBadge) householdIdBadge.textContent = text;
  }

  // เริ่มต้นจาก local
  setHouseholdUI(me.householdId || null);

  let currentGroupId = me.householdId || null;

  // -----------------------------
  // helper: โหลดสมาชิกกลุ่ม
  // -----------------------------
  async function loadGroupMembers(groupId) {
    if (!memberList) return;
    memberList.innerHTML = '<div class="small">Loading members...</div>';

    try {
      const res = await fetch(
        `${ApiConfig.apiBaseUrl}/groups/${groupId}/members`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${Auth.getToken()}`,
            'x-user-id': me.userId || me.sub || me.id,
          },
        }
      );

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        const msg = errBody.error || 'Failed to load members';

        // ★★ ถ้า backend บอกว่าไม่ใช่สมาชิกแล้ว → reset frontend ให้หมด ★★
        if (msg.includes('Not a member')) {
          console.warn('Not a member anymore, clearing householdId');
          Auth.updateUser({ householdId: null });
          currentGroupId = null;
          setHouseholdUI(null);

          memberList.innerHTML =
            '<div class="small">Create or join a group to see members</div>';

          return; // ไม่ต้อง throw ต่อ
        }

        throw new Error(msg);
      }

      const data = await res.json();
      console.log('Members:', data);

      memberList.innerHTML = '';

      if (!data.members || data.members.length === 0) {
        memberList.innerHTML = '<div class="small">No members yet</div>';
        return;
      }

      data.members.forEach(m => {
        const chip = document.createElement('div');
        chip.className = 'badge';
        chip.style.display = 'inline-flex';
        chip.style.alignItems = 'center';
        chip.style.gap = '6px';
        chip.style.margin = '4px';

        const roleColors = {
          owner: '#3b82f6',
          admin: '#8b5cf6',
          member: '#6b7280',
        };
        chip.style.background = roleColors[m.role] || '#6b7280';
        chip.style.color = 'white';

        chip.innerHTML = `
          <span style="font-weight:600">${m.userName || 'Member'}</span>
          <span style="opacity:0.8;font-size:11px">${m.role}</span>
        `;

        memberList.appendChild(chip);
      });

    } catch (err) {
      console.error('Load members error:', err);
      if (memberList) {
        memberList.innerHTML =
          `<div class="small" style="color:#ef4444">Error: ${err.message}</div>`;
      }
    }
  }

  // -----------------------------
  // โหลด profile จาก backend
  // -----------------------------
  async function loadProfile() {
    try {
      const profile = await Api.getUserProfile();
      console.log('Loaded user profile from API:', profile);

      // sync เข้า Auth
      Auth.updateUser({
        householdId: profile.primaryGroupID || null,
        avatar: profile.avatar || me.avatar || null,
      });

      const refreshed = Auth.current();
      currentGroupId = refreshed.householdId || null;

      setHouseholdUI(currentGroupId);

      if (currentGroupId) {
        await loadGroupMembers(currentGroupId);
      } else if (memberList) {
        memberList.innerHTML =
          '<div class="small">Create or join a group to see members</div>';
      }
    } catch (err) {
      console.error('Failed to load profile', err);
      // ถ้าเรียก profile ไม่ได้ จะใช้ค่าจาก local ต่อ
      if (memberList && !currentGroupId) {
        memberList.innerHTML =
          '<div class="small">Create or join a group to see members</div>';
      }
    }
  }

  await loadProfile();

  // =====================================================
  // ปุ่ม Create Household
  // =====================================================
  document.getElementById('createHousehold')
    .addEventListener('click', async () => {
      const groupName = prompt('Enter group name:', 'My Family');
      if (!groupName) return;

      try {
        showToast('Creating group...', 'info');

        const res = await fetch(`${ApiConfig.apiBaseUrl}/groups`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${Auth.getToken()}`,
            'Content-Type': 'application/json',
            'x-user-id': me.userId || me.sub || me.id,
          },
          body: JSON.stringify({
            groupName: groupName.trim(),
            maxMembers: 10,
            userName: me.name,
            userEmail: me.email,
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to create group');
        }

        const data = await res.json();
        console.log('Group created:', data);

        Auth.updateUser({ householdId: data.group.groupId });
        currentGroupId = data.group.groupId;
        setHouseholdUI(currentGroupId);

        showToast(`✅ Group "${groupName}" created!`, 'success');
        await loadGroupMembers(currentGroupId);

      } catch (err) {
        console.error('Create group error:', err);
        showToast('❌ ' + err.message, 'error');
      }
    });

  // =====================================================
  // ปุ่ม Get Invite Code
  // =====================================================
  document.getElementById('showInvite')
    .addEventListener('click', async () => {
      if (!currentGroupId) {
        showToast('You are not in a group', 'error');
        return;
      }
      try {
        showToast('Generating invite code...', 'info');

        const res = await fetch(
          `${ApiConfig.apiBaseUrl}/groups/${currentGroupId}/invite`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${Auth.getToken()}`,
              'Content-Type': 'application/json',
              'x-user-id': me.userId || me.sub || me.id,
            },
          }
        );

        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to get invite code');
        }

        const data = await res.json();
        const inviteCode = data.inviteCode;

        document.getElementById('inviteDisplay').textContent =
          `Invite Code: ${inviteCode}`;

        if (navigator.clipboard) {
          await navigator.clipboard.writeText(inviteCode);
          showToast(`✅ Invite code copied: ${inviteCode}`, 'success');
        } else {
          showToast(`Invite Code: ${inviteCode}`, 'success');
        }
      } catch (err) {
        console.error('Get invite code error:', err);
        showToast('❌ ' + err.message, 'error');
      }
    });

  // =====================================================
  // ปุ่ม Join Group
  // =====================================================
  document.getElementById('joinBtn')
    .addEventListener('click', async () => {
      const inviteCode = document.getElementById('joinCode').value.trim();
      if (!inviteCode) {
        showToast('⚠️ Please enter invite code', 'error');
        return;
      }

      try {
        showToast('Joining group...', 'info');

        const res = await fetch(`${ApiConfig.apiBaseUrl}/groups/join`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${Auth.getToken()}`,
            'Content-Type': 'application/json',
            'x-user-id': me.userId || me.sub || me.id,
          },
          body: JSON.stringify({
            inviteCode: inviteCode.toUpperCase(),
            userName: me.name,
            userEmail: me.email,
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || 'Failed to join group');
        }

        const data = await res.json();
        console.log('Joined group:', data);

        Auth.updateUser({ householdId: data.group.groupId });
        currentGroupId = data.group.groupId;
        setHouseholdUI(currentGroupId);

        showToast(`✅ Joined "${data.group.groupName}"!`, 'success');
        await loadGroupMembers(currentGroupId);

      } catch (err) {
        console.error('Join group error:', err);
        showToast('❌ ' + err.message, 'error');
      }
    });

  // =====================================================
  // Shared Inventory Modal
  // =====================================================
  const sharedBtn = document.getElementById('sharedInventoryBtn');
  const leaveBtn = document.getElementById('leaveGroupBtn');
  const sharedModal = document.getElementById('sharedInventoryModal');
  const closeSharedModal = document.getElementById('closeSharedModal');
  const confirmShareBtn = document.getElementById('confirmShareBtn');
  const inventoryCheckList = document.getElementById('inventoryCheckList');

  if (sharedBtn && sharedModal && inventoryCheckList) {
    sharedBtn.addEventListener('click', async () => {
      const user = Auth.current();
      if (!user.householdId) {
        alert('You are not in a household.');
        return;
      }

      sharedModal.classList.remove('hidden');
      inventoryCheckList.innerHTML = "<div style='padding:6px;'>Loading...</div>";

      try {
        const items = await Api.listIngredients();
        inventoryCheckList.innerHTML = items.map(i => `
          <label style="display:flex; gap:6px; margin-bottom:6px;">
            <input type="checkbox"
                   data-name="${i.name}"
                   data-qty="${i.quantity}"
                   data-unit="${i.unit}"
                   data-expiry="${i.expiry}">
            <span>${i.name} — ${i.quantity} ${i.unit}</span>
          </label>
        `).join('');
      } catch (err) {
        console.error(err);
        inventoryCheckList.innerHTML = '<div>Error loading items</div>';
      }
    });
  }

  if (closeSharedModal && sharedModal) {
    closeSharedModal.addEventListener('click', () => {
      sharedModal.classList.add('hidden');
    });
  }

  if (confirmShareBtn && inventoryCheckList) {
    confirmShareBtn.addEventListener('click', async () => {
      const user = Auth.current();
      const groupId = user.householdId;
      if (!groupId) {
        alert('You are not in a household.');
        return;
      }

      const checks = inventoryCheckList
        .querySelectorAll('input[type=checkbox]:checked');

      if (checks.length === 0) {
        alert('Please select at least 1 item.');
        return;
      }

      try {
        for (let c of checks) {
          await Api.addGroupItem(groupId, {
            name: c.dataset.name,
            quantity: Number(c.dataset.qty),
            unit: c.dataset.unit,
            expiry: c.dataset.expiry,
            category: 'misc',
          });
        }
        alert('Shared successfully!');
        sharedModal.classList.add('hidden');
      } catch (err) {
        console.error(err);
        alert('Failed to share.');
      }
    });
  }

  // =====================================================
  // Leave Household
  // =====================================================
  if (leaveBtn) {
    leaveBtn.addEventListener('click', async () => {
      if (!confirm('Are you sure you want to leave this household?')) return;

      try {
        const user = Auth.current();
        if (!user) {
          alert('Session expired, please login again.');
          Auth.logout();
          return;
        }

        const groupId = user.householdId;
        if (!groupId) {
          alert('You are not in a household.');
          return;
        }

        const userId = user.userId || user.sub || user.id;

        await Api.removeGroupMember(groupId, userId);

        Auth.updateUser({ householdId: null });
        currentGroupId = null;
        setHouseholdUI(null);

        if (memberList) {
          memberList.innerHTML =
            '<div class="small">Create or join a group to see members</div>';
        }

        alert('You have left the household.');
      } catch (err) {
        console.error('Leave household error:', err);
        alert('Unable to leave household.');
      }
    });
  }

  // Avatar / display name / logout เดิม
  document.getElementById('avatarInput')
    .addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        Auth.updateUser({ avatar: reader.result });
        showToast('✅ Avatar updated', 'success');
        location.reload();
      };
      reader.readAsDataURL(file);
    });

  document.getElementById('displayName')
    .addEventListener('change', () => {
      const user = Auth.current();
      user.name = document.getElementById('displayName').value.trim() || user.name;
      localStorage.setItem('fs_auth', JSON.stringify(user));
      document.getElementById('name').textContent = user.name;
      showToast('✅ Display name updated', 'success');
    });

  document.getElementById('logout')
    .addEventListener('click', (e) => {
      e.preventDefault();
      Auth.logout();
    });
});

// ====== Toast Notification (ของเดิมใช้ต่อได้) ======
function showToast(message, type = 'info') {
  if (typeof UI !== 'undefined' && UI.toast) {
    UI.toast(message);
    return;
  }
  let toastContainer = document.querySelector('.toast');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast';
    toastContainer.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      max-width: 300px;
    `;
    document.body.appendChild(toastContainer);
  }
  const toast = document.createElement('div');
  toast.className = `toast-message ${type}`;
  toast.style.cssText = `
    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    margin-bottom: 10px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    animation: slideIn 0.3s ease-out;
  `;
  toast.textContent = message;
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'slideIn 0.3s ease-out reverse';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
