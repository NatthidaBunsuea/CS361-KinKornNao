const UI = (() => {
    function mountHeader(){
      const user = Auth.current();
      const avatarSrc = user?.avatar || '../assets/avatar.svg';
      const header = document.createElement('div');
      header.innerHTML = `<header class="header">
    <div class="brand">
      <img src="../assets/avatar.svg" alt="logo"/>
      <div>
        <h1>KinKonNao™</h1>
        <div class="small">Foodie is goodie, Family loves food.</div>
      </div>
    </div>
    <nav class="nav" style="display:flex;align-items:center;gap:8px">
      <span class="badge house" title="Household">${user?.householdId||'—'}</span>
      <a href="../pages/ingredient-form.html">+เพิ่มวัตถุดิบ</a>
      <a href="../pages/fridge-list.html">รายการในตู้เย็น</a>
      <a href="../pages/recipes.html">แนะนำเมนู</a>
      <a href="../pages/dashboard.html">Weekly Dashboard</a>
      <a href="../pages/profile.html">Profile</a>
      <a href="#" id="logoutLink">Logout</a>
      <img class="avatar" alt="avatar" src="${avatarSrc}" style="width:36px;height:36px;border-radius:50%"/>
    </nav>
  </header>`;
      document.body.prepend(header.firstElementChild);
      const logoutLink = document.getElementById('logoutLink');
      if(logoutLink){ logoutLink.addEventListener('click', (e)=>{ e.preventDefault(); Auth.logout(); }); }
      document.querySelectorAll('.nav a').forEach(a=>{
        if(location.pathname.endsWith(a.getAttribute('href').split('/').pop())) a.classList.add('active');
      });
    }
    function toast(msg){
      let t = document.querySelector('.toast');
      if(!t){ t=document.createElement('div'); t.className='toast'; document.body.appendChild(t); }
      t.textContent = msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),1800);
    }
    const fmtDate = d => d ? new Date(d).toLocaleDateString() : '';
    function daysUntil(d){ const t=new Date(d).setHours(0,0,0,0), now=new Date().setHours(0,0,0,0); return Math.round((t-now)/86400000); }
    return { mountHeader, toast, fmtDate, daysUntil };
  })();